/* ========================================================================== */
/* PROGRAM: Bookstore Order Estimation
   AUTHOR: <Jack Moran>
   FSU MAIL NAME: <jm19bt>
   RECITATION SECTION NUMBER: <0006>
   RECITATION INSTRUCTOR NAME: <Uzoamaka Ezeakunne>
   COP 3363 - Fall 2020 
   PROJECT NUMBER: 2 
   DUE DATE: Wednesday 9/23/2020
   PLATFORM: g++ / UNIX OS

SUMMARY

A college bookstore wants to estimate its business for next term. Experience
has shown that sales for a course textbook depend greatly on whether a book
is required or just suggested reading, and whether or not it has been used
for a course in previous terms. This program is intended to help the bookstore
handle the logistics surrounding these facts.


INPUT

This program takes as input a book's ID number, the cost per copy, the
current number of volumes on hand, the expected course enrollment, and a
char indicating whether the textbook is required or suggested, as well as a
char for whether it is new or old. 


OUTPUT

First give the number of books that must be ordered (if any). Then, if books
must be ordered, show the total cost the store must pay for the books
ordered, and the expected profit on the books ordered assuming that the store
pays 80% of list price to obtain them from its supplier, and sells them for
list price.

ASSUMPTIONS

-All input data is valid and correctly entered by the user.
  
-The statistics regarding the sales of different types of textbooks are
appropriately calculated.

-The currency used to purchase textbooks is US Dollars.

/

/* ==========================================================================*/
/* HEADER FILES */

#include <iostream>
#include <iomanip>
#include <cmath>

using namespace std;

/* =========================================================================*/ 
/* MAIN FUNCTION */

int main()
{
    //Variables to store input

    int bookID,            // The book's ID number
        volumes,           // Number of volumes in stock
        enrollment;        // Expected enrollment

    double cost;           // The cost per book

    //Variables used for logic and arithmetic
    char bookType,         //Required or suggested? Should only be 'R' or 'S'
         bookAge;          //New or Old? Should only be 'N' or 'O'

    int orders;            //The number of books to order, rounded up

    double orderCost,      //The total cost of the order
           profit;         //The profit expected from the order

    // prints the heading
    cout << "===================================================" << endl;
    cout << "Welcome to the Bookstore Order Estimation Program!" << endl;
    cout << "===================================================" << endl 
         << endl;
    
    // Requests the appropriate user input
    cout << "Please enter the book's ID number: ";
    cin >> bookID;
    cout << "Enter the cost for each copy: ";
    cin >> cost;
    cout << "Enter the number of volumes in stock: ";
    cin >> volumes;
    cout << "Enter the expected class enrollment: ";
    cin >> enrollment;
    cout << "Is the book required or suggested? Enter 'R' or 'S': ";
    cin >> bookType;
    cout << "Is the book new (has never been used) or old (has been used before)? Enter 'N' or 'O': ";
    cin >> bookAge;

    // Prints the output header in advance
    cout << "=====================================================" << endl;
    cout << "            Book Order Estimation Summary" << endl;
    cout << "=====================================================" << endl;

    // Calculates the number of books to order based on the two chars
    // 0.5 is added to ensure that the number is never rounded down
    if (bookType == 'R') {
       if (bookAge == 'N') {
         orders = round((enrollment * 0.9) - volumes + 0.5);
       }
      
       else if(bookAge == 'O') {
         orders = round((enrollment * 0.65) - volumes + 0.5);
       }
    }

    else if (bookType == 'S') {
       if (bookAge == 'N') {
         orders = round((enrollment * 0.4) - volumes + 0.5);
       }

       else if(bookAge == 'O') {
         orders = round((enrollment * 0.2) - volumes + 0.5);
       }
    }

    //Ensures there are no negative results, as this wouldn't make sense
    if (orders < 0)
    {
      orders = 0;
    }

    //Prints the ID and the number of books to order

    cout << "Book ID Number: " << bookID << endl;
    cout << "Number of Books to Order: " << orders << endl;
    
    //Terminates the program early if no book orders are necessary

    if (orders > 0) {
      //Calculates the total cost of the order and the expected profit
      
      orderCost = orders * cost;
      profit = (orderCost/0.8) - orderCost;

      //Prints the resulting order cost and profit
     
      cout << "Total Cost of this Order: $" << orderCost << endl;
      cout << "Expected Profit on Books Ordered: $" << profit << endl;
    }    
    
    cout << "Bookstore program terminated." << endl;

    return 0;
}

/* ========================================================================== */ 
/*                      E N D   O F   P R O G R A M                           */
/* ========================================================================== */
