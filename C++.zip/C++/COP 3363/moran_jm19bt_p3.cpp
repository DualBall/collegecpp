/* ========================================================================== */
/* PROGRAM: HTML File Analyzer
   AUTHOR: <Jack Moran>
   FSU MAIL NAME: <jm19bt>
   RECITATION SECTION NUMBER: <0006>
   RECITATION INSTRUCTOR NAME: <Uzoamaka Ezeakunne>
   COP 3363 - Fall 2020 
   PROJECT NUMBER: 3
   DUE DATE: Wednesday 10/7/2020
   PLATFORM: g++ / UNIX OS

SUMMARY

This program is designed to read in an HTML file, determine the numbers of
different properties in the file, and communicate this information to the user.

INPUT

The only user input taken in this program is the name of the file the
user wants analyzed. In this test version, the only valid selections are those
within the same UNIX directory as this program. 

OUTPUT

The text of the file comes first. After that, the amount of the following
properties are presented: lines, tags, comments, links, chars in file, and 
chars in tags. The percentage of characters in tags is also given.

ASSUMPTIONS

-All input data is valid and correctly entered by the user.
  
-The user's file of choice is already in this directory (see above).

-The code in the file is written in HTML, with no syntax errors.

*/
/* ==========================================================================*/
/* HEADER FILES */

#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>

using namespace std;

/* =========================================================================*/ 
/* MAIN FUNCTION */

int main()
{
    string fileName;          //User's input

    //Variables to store amounts

    int numLines = 0,          // Number of lines
        numTags = 0,           // Number of tags
	numLinks = 0,	   // Number of links
	numChars = 0,          // Number of characters in file
	numTagChars = 0,       // Number of characters in tags
	numComments = 0;   // Number of comments

    double inTags;         // The percentage of characters in tags

    //Variables and constants used in logic
    char current;          //The current character being read in
    
    const char TAG_START = '<',
	       TAG_END = '>',
	       LINE = '\n',
	       LINK_LOW = 'a',
	       LINK_UP = 'A',
               COMMENT = '!';

    // prints the heading
    cout << "===================================================" << endl;
    cout << "        Welcome to the HTML File Analyzer!" << endl;
    cout << "===================================================" << endl 
         << endl;

	cout << numComments;
    
    // Requests the appropriate user input
    cout << "Enter a valid filename (no blanks!): ";
    cin >> fileName;

    // Prints the first header in advance
    cout << "=====================================================" << endl;
    cout << "                      File text" << endl;
    cout << "=====================================================" << endl
	 << LINE << endl;

    //Sets up the file for the program
    ifstream infile;
    infile.open(fileName.c_str());
    infile.get(current);
    
    //Prompts the user for a different input until the filename is correct
    while(!infile)
    {
      cout << "Sorry, but the file name you typed in is not valid." << endl;
      cout << "Enter a valid filename (no blanks!): ";
      cin >> fileName;
      infile.open(fileName.c_str());
      infile.get(current);
    }

    //The file begins to be read here.
    while(infile)
    {
      
      ++numChars;		//Counts this character
      cout << current;		//Prints the current character
      
      //Checks to see if a tag is beginning and responds appropriately

      if (current == TAG_START)
      {
	++numTags;		//Counts this tag
	infile.get(current);    //Moves on to prepare for the switch
	
	//Checks to see what should be counted next

	  if ((current == LINK_LOW) || (current == LINK_UP)) 
	  {
	    ++numLinks;
	  }
	  else if (current == COMMENT) 
	  {
	    ++numComments;
	  }

	//Begins a separate while loop to handle additional counting/printing
	
	while (current != TAG_END)
	{
	  ++numChars;		//Counts this character
	  cout << current;      //Prints this character
	  ++numTagChars;	//Counts this tag character
	  infile.get(current);  //Moves on
	}
	
        ++numChars;		//Counts the end of the tag
	cout << current;	//Prints the end of the tag
      }
      
      //Counts new lines

      if (current == LINE)
          {
            numLines++;
          }

      infile.get(current); //Moves on so the loop can progress properly
    }

    //Calculates the percentage of characters in tags
    inTags = ((double)numTagChars / numChars) * 100;

    //Prints the footer

    cout << endl;
    cout << "=====================================================" << endl;
    cout << "                   End of File Text" << endl;
    cout << "=====================================================" << endl
         << endl;

    // Prints the results
    cout << "Analysis of file" << endl;
    cout << "----------------" << endl
	 << endl;

    cout << "Number of lines: " << numLines  << endl;
    cout << "Number of tags: "  << numTags <<  endl;
    cout << "Number of comments: " << numComments << endl;
    cout << "Number of links: " << numLinks  << endl;
    cout << "Number of chars in file: " << numChars << endl;
    cout << "Number of chars in tags: " << numTagChars << endl;
    cout << "Percentage of characters in tags: ";
    cout << setprecision(4) << inTags << "%" << endl
         << endl;

    //prints the footer
    cout << "===================================================" << endl;
    cout << "    Thank you for using the HTML File Analyzer" << endl;
    cout << "===================================================" << endl
         << endl;


    return 0;
}

/* ========================================================================== */ 
/*                      E N D   O F   P R O G R A M                           */
/* ========================================================================== */

