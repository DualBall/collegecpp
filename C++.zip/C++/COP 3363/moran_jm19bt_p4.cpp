/* ========================================================================== */
/* PROGRAM: Monty Hall Puzzle
   AUTHOR: <Jack Moran>
   FSU MAIL NAME: <jm19bt>
   RECITATION SECTION NUMBER: <0006>
   RECITATION INSTRUCTOR NAME: <Uzoamaka Ezeakunne>
   COP 3363 - Fall 2020 
   PROJECT NUMBER: 4
   DUE DATE: Wednesday 10/30/2020
   PLATFORM: g++ / UNIX OS

SUMMARY

This program is designed to simulate the Monty Hall Puzzle, and empirically
determine the most efficient strategy that can be used to 'solve' it. The
following three strategies will be tested over the course of 1000 trials for
each strategy:

* Always stay with the door initially picked
* Randomly stay or switch (50/50 odds will be used for this strategy)
* Always switch to the unpicked and unopened door.

INPUT

No input is necessary for this program to run.

OUTPUT

First, the program will show an explanation of the strategies employed, in
the proper order. Then, the program will report on the results of each
simulation, showing the numbers of games played, the number of games won,
and the percentage of games won to the 2nd decimal point. Finally, each
strategy will be ranked for effectiveness, and a winner will be determined.

ASSUMPTIONS

-The user knows the rules of the Monty Hall Puzzle

*/
/* ==========================================================================*/
/* HEADER FILES */

#include <iostream>
#include <iomanip>
#include <cstdlib>
#include <ctime>

using namespace std;

/* =========================================================================*/
/* FUNCTION PROTOTYPES */

void printData (int, int, double); //prototype for printing results
int drawNum (int);                 // prototype for random numbers
double percentage(int, int);       // prototype for percentages

/* ========================================================================= */
 
/* MAIN FUNCTION */

int main()
{
    //Variables to store strategy rankings
    string first,
	   second,
	   third;

    //Variables to store amounts

    const int NUM_GAMES = 1000;

    int car = 0,	       //Stores the door with the car behind it
	pick = 0,              //Stores the contestant's choice of door
	open = 0,	       //Stores the door opened
	winsOne = 0,           // Number of wins for each strategy
	winsTwo = 0,
	winsThree = 0;

    double winPercentOne,      // The percentage of wins for each strategy
	   winPercentTwo,
	   winPercentThree;

    unsigned int seed;               /* seeds (initializes) rand() */

    /* get a value for the time from the computer's clock and with */
    /* it call srand to initialize "seed" for the rand() function */
    seed = static_cast<unsigned>(time (NULL));
    srand (seed);

    //Begins running the trials
    for (int i = 0; i < NUM_GAMES; i++)
    {
      //Sets up the "position" of the car and the door picked
      car = drawNum(3);
      pick = drawNum(3);

      //Throws an error if drawNum works wrong. For bugfixing only.
      if (car > 3 || pick > 3)
      {
        cout << "drawNum has an error!" << endl;
      }

      //Decides the door opened. Remember, it can't be the one with the car!

      if (pick == car)	//These if's handle cases where pick and car match
      {
	if (pick == 1)
	{
	  open = drawNum(2) + 1;
	}
        else if (pick == 2) 
        {
          drawNum(2) == 1 ? open = 1 : open = 3; //Logic supplements randNum
        }
        else if (pick == 3) 
        {
          open = drawNum(2);
        }
      }
      else if (pick == 1)  //These if's select the door without the car
      {
	car == 2 ? open = 3 : open = 2;
      }
      else if (pick == 2)        
      {
        car == 1 ? open = 3 : open = 1;
      }
      else
      {
        car == 1 ? open = 2 : open = 1;
      }

      //Implements Strategy 1
      if (pick == car)
      {
        winsOne++;
      }

      //Implements Strategy 2. This should contain the other two
      if (drawNum(2) == 1)
      {
        if (pick == car)
        {
          winsTwo++;
        }
      }
      else
      {
        if (1 != pick && 1 != open && 1 == car)
        {
          winsTwo++;
        }
        else if (2 != pick && 2 != open && 2 == car)
        {
          winsTwo++;
        }
        else if (3 != pick && 3 != open && 3 == car) //Needs to be else if!
        {
          winsTwo++;
        }
      }

      //Implements Strategy 3
      if (1 != pick && 1 != open && 1 == car)
      {
        winsThree++;
      }
      else if (2 != pick && 2 != open && 2 == car)
      {
        winsThree++;
      }
      else if (3 != pick && 3 != open && 3 == car) //Needs to be else if!
      {
        winsThree++;
      }
    }

    //Calculates the percentages of wins for each strategy

    winPercentOne = percentage(winsOne, NUM_GAMES);
    winPercentTwo = percentage(winsTwo, NUM_GAMES);   
    winPercentThree = percentage(winsThree, NUM_GAMES);

    //Decides the rankings

    if(winPercentOne > winPercentTwo && winPercentOne > winPercentThree)
    {
      first = "Strategy 1";
      
      if(winPercentTwo > winPercentThree)
      {
	second = "Strategy 2";
	third = "Strategy 3";
      }
      else
      {
	second = "Strategy 3";
	third = "Strategy 2";
      }
    }
    else if(winPercentTwo > winPercentOne && winPercentTwo > winPercentThree)
    {
      first = "Strategy 2";

      if(winPercentOne > winPercentThree)
      {
        second = "Strategy 1";
        third = "Strategy 3";
      }
      else 
      {
        second = "Strategy 3";
        third = "Strategy 1";
      }
    }
    else
    {
      first = "Strategy 3";

      if(winPercentOne > winPercentTwo)
      {
        second = "Strategy 1";
        third = "Strategy 2";
      }
      else 
      {
        second = "Strategy 2";
        third = "Strategy 1";
      }
    }

    //Prints the data

    cout << endl;
    cout << "=====================================================" << endl;
    cout << "     Welcome to the Monty Hall Puzzle Simulator!"      << endl;
    cout << "=====================================================" << endl
         << endl;

    cout << "Strategy 1: Always stay with the door initially picked" << endl;
    cout << "------------------------------------------------------" << endl
	 << endl;

    printData(NUM_GAMES, winsOne, winPercentOne);

    cout << "Strategy 2: Randomly stay or switch doors (50/50 odds)" << endl;
    cout << "------------------------------------------------------" << endl
         << endl;

    printData(NUM_GAMES, winsTwo, winPercentTwo);

    cout << "Strategy 3: Always switch to the unpicked and unopened door" 
         << endl;
    cout << "------------------------------------------------------" << endl
         << endl;

    printData(NUM_GAMES, winsThree, winPercentThree);

    //Prints the final results

    cout << endl;
    cout << "=====================================================" << endl;
    cout << "                      The Verdict" << endl;
    cout << "=====================================================" << endl
         << endl;

    cout << "Most effective strategy: " << first << endl;
    cout << "Second most effective strategy: " << second << endl;
    cout << "Third most effective strategy: " << third << endl;

    return 0;
}   /* END OF MAIN FUNCTION

/* ========================================================================= */

/**************************************************/
/*       	  FUNCTION drawNum     		  */
/* Returns a random number in the specified range */
/**************************************************/

int drawNum (int max)    // max is the maximum number to generate
{
  double x = RAND_MAX + 1.0;        /* x and y are both auxiliary*/
  int y;                            /* variables used to do the calculation */
   
  y = static_cast<int> (1 + rand() * (max / x));
  return (y); //returns the random number
}

/**************************************************/
/*                FUNCTION percentage             */
/*   Calculates a percentage based on the input   */
/**************************************************/


double percentage (int low, int high)
{
  return ((double)low / high) * 100;
}

/**************************************************/
/*                FUNCTION printData              */
/*           Handles the printing of data         */
/**************************************************/


void printData (int games, int wins, double winRate)
{
    cout << "Number of games played: " << games << endl;
    cout << "Number of games won: "  << wins <<  endl;
    cout << "Percentage of games won: " << setprecision(5) << winRate
         << "%" << endl
         << endl;
}

/* =========================================================================*/ 
/*                      E N D   O F   P R O G R A M                         */
/* =========================================================================*/

