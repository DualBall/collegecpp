/* ========================================================================== */
/* PROGRAM: Automated Exam Grader
   AUTHOR: <Jack Moran>
   FSU MAIL NAME: <jm19bt>
   RECITATION SECTION NUMBER: <0006>
   RECITATION INSTRUCTOR NAME: <Uzoamaka Ezeakunne>
   COP 3363 - Fall 2020 
   PROJECT NUMBER: 5
   DUE DATE: Saturday 11/14/2020
   PLATFORM: g++ / UNIX OS

SUMMARY

This program is designed to read in xfile.txt and create a histogram based on
the test scores within, while also calculating the mean exam score.

INPUT

The file xfile.txt, whose data will be stored in appropriate arrays.

OUTPUT

Echoprinted input, a table containing information about the students and their
answers/scores, and the mean score, along with a histogram describing how many
students received scores in ranges with intervals of 5.

ASSUMPTIONS

-The file being used is xfile.txt.
  
-The answer key in the first line of the file is correct.

-The student names are valid.

*/
/* ==========================================================================*/
/* HEADER FILES */

#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstdlib>
#include <string>

using namespace std;

typedef int StudentScores [25];
typedef int Frequency [6];
typedef char StudentAnswers [30];

/* =========================================================================*/
/* FUNCTION PROTOTYPES */

int frequencyCalc (const StudentScores scores, int low, int high);
void asterisks (int amount);

/* =========================================================================*/ 
/* MAIN FUNCTION */

int main()
{
    const string FILE_NAME = "xfile.txt";          //Name of the file
    string currString;                  //The current string being read in.
    char currChar;			//The current character being read in.
    bool error;		//Keeps track of whether there are any invalid answers.

    int low = 0,		//Both used for score ranges in the histogram
    high = 5;   
    double mean;	//The mean of the scores

    //Arrays to store data

    StudentScores scores = {};			//Scores of students
    StudentAnswers answers = {};			//Answers for each student
    Frequency freq = {0, 0, 0, 0, 0, 0};		//Frequency of different scores
 
    char testKey [30] = {};			// Test answers
    string studentFirstNames [25] = {};         // Names of students
    string studentLastNames [25] = {};
    
    //Sets up the file for the program
    ifstream infile;
    infile.open(FILE_NAME.c_str());
    infile.get(currChar);
    

    //Kills the program if the file was not opened successfully.
    if(!infile)
    {
      cout << "ERROR: the file has failed to open. Check to make sure the file is in";
      cout << " the appropriate directory, and that it is named correctly." << endl;
      exit(EXIT_FAILURE);
    }

    // prints the test result headers in advance
    cout << "==========================================================================" << endl;
    cout << "                               Test results" << endl;
    cout << "==========================================================================" << endl
         << endl;

    cout << " Student Names                 Test Answers                        Scores " << endl;
    cout << "--------------------------------------------------------------------------" << endl
         << endl;

    //The file begins to be read here.
    //Reads in the test key
    for (int i = 0; i < 30; i++)
      {
	infile.get(testKey[i]);
      }

    for (int i = 0; i < 25; i++)
      {
	//Reads in and prints the student names
	getline(infile, studentFirstNames[i], ' ');
	getline(infile, studentLastNames[i]);
	infile.ignore();
	cout << " " << setw(20) << left << (studentFirstNames[i] + " " + studentLastNames[i]);
        cout << "   ";

	//Handles student answers and scores, all in one loop!
	for (int j = 0; j < 30; j++)
	{
	  infile.get(answers[j]);    //Reads in the answers
	  
	  //Scores each student
	  if (answers[j] == testKey[j])
           {
             //cout << "Score added";
             scores[i]++;  //Adds to the current student's score
           }
     
          //Checks for invalid answers
          else if (answers[j] != 'T' && answers[j] != 'F')
           {
             error = true;
           }
 
	  if (answers[j] != '\n')  //Prevents a new line
	  {
	    cout << answers[j]; //Prints this student's answers
	  }
	}
	
	//Prints this student's score
	cout << setw(20) << right << scores[i] << endl;

	//Prints an error if any of the student's answers were invalid
	if (error)
	{
	  cout << "WARNING: the last student entered one or more ";
          cout << " invalid answers. Any " << endl;
          cout << "invalid answers have been marked incorrect." << endl;

	  error = false;
	}
      }
    
    infile.close();

    cout << endl;
    
    //Calculates and prints the mean score
    int sum = 0;

    for (int i = 0; i < 25; i++)
      {
        sum += scores[i];
      }

    mean = (sum / 25.0);

    cout << "Mean score: " << setprecision(4) << mean <<  endl
         << endl;


    //Prepares the frequency array for the histogram

    for (int i = 0; i < 6; i++)
      {

	//Finds the frequency of this score range
	freq[i] = frequencyCalc(scores, low, high);
	//cout << freq[i];   For Debugging

	low += 5;
	high += 5;
	if (i == 0)
          low++;   //Ensures the lower bounds work right for each iteration
      }

    //Resets low and high
    low = 0;
    high = 0;

    //Prints the histogram headers
    cout << endl;
    cout << "=====================================================" << endl;
    cout << "                      Histogram" << endl;
    cout << "=====================================================" << endl
         << endl;

    cout << "Score Ranges   Obtained by      5   10   15   20   25" << endl;
    cout << "------------   -----------  ----|----|----|----|----|" << endl
	 << endl;
	
    //Prints the histogram
    for (int j = 0; j < 6; j++)
    {
      //cout << setw(12) << left << (low + "..." + high);
      cout << "	 " << setw(10) << left << freq[j];
      cout << "	 ";
      asterisks(freq[j]);
      cout << endl;

      low += 5;
      high += 5;
      if (j == 0)
	low++;   //Ensures the lower bounds work right for each iteration
    }

    return (EXIT_SUCCESS);
}
/* ========================================================================= */

//Determines the frequency of a given score range
int frequencyCalc (const StudentScores scores, int low, int high)
{
  cout << low << "..." << high;  //prints the given score range
  
  int result = 0;

  for (int i = 0; i < 25; i++)
    {
      if (scores[i] > low && scores[i] < high) //Checks if current score is in range
	{
	  result++;
	}
    }

  
  return result;   //Returns the frequency of this range
}

//Prints the asterisks for the histogram
void asterisks (int amount)
{
  for (int i = 0; i < amount; i++)
    {
      cout << "*";
    }

}
/* ========================================================================== */ 
/*                      E N D   O F   P R O G R A M                           */
/* ========================================================================== */

