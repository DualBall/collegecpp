/* ========================================================================== */
/* PROGRAM: Mini Hurricane Database
   AUTHOR: <Jack Moran>
   FSU MAIL NAME: <jm19bt>
   RECITATION SECTION NUMBER: <0006>
   RECITATION INSTRUCTOR NAME: <Uzoamaka Ezeakunne>
   COP 3363 - Fall 2020 
   PROJECT NUMBER: 5
   DUE DATE: Wednesday 12/2/2020
   PLATFORM: g++ / UNIX OS

SUMMARY

This program is designed to read in hurricaneCosts.txt and use it to create
a hurriance database which the user can browse.

INPUT

Before runtime: The file hurricaneCosts.txt, whose data will be stored in 
an array of structs. During runtime: one of 3 user choices:

1: Display data for a particular hurricane

2: Display all hurricane names within a category

3: Quit the program.

OUTPUT

Before runtime: The data from the file, stored in alphabetical order.
During runtime: Any information the user requests, as well as error
messages for incorrect choices. If the file does not open for any
reason, an error message will be printed for this as well. 

ASSUMPTIONS

-The file being used is hurricaneCosts.txt.
  
-All hurricane data in the file is accurate.

-The file will contain data for, at most, 50 storms.

-The user types in valid hurricane names.

*/
/* ==========================================================================*/
/* HEADER FILES */

#include <iostream>
#include <fstream>
#include <cstdlib>
#include <string>
#include <cctype>

using namespace std;

/* =========================================================================*/
/* STRUCTS AND TYPEDEFS*/

//Contains data for each hurricane 
struct Hurri
{
   int rank;	  //An integer that ranks the hurricane based on cost
   string name,	  //The hurricanes' name
	  stateCode;	//The code for the state the hurricane was in
   int year, category;	//The year and category of the hurricane
   double damage;	//The damage cost of the hurricane, in dollars
};

const int MAXNUMSTORMS = 50;		//The maximum number of hurricanes
typedef Hurri StormList [MAXNUMSTORMS];	//Defines a type of struct array

/* =========================================================================*/
/* FUNCTION PROTOTYPES */

void SortStorms (int numHurris, StormList hurricanes);
void printMenu ();
void choiceOne (StormList hurricanes, int length);
void choiceTwo (StormList hurricanes, int length);
void StringToLower (string& s);
/* =========================================================================*/
 

/* MAIN FUNCTION */

int main()
{
    /* BEGINNING OF DECLARATIONS */
    
    //Related to reading in the file
    const string FILE_NAME = "hurricaneCosts.txt";	  //Name of the file
    StormList hurricanes;    //The array of structs that store the data

    int numHurricanes= 0,	//The number of hurricanes
        userChoice;		//The user's menu choice 
    
    /* END OF DECLARATIONS */
    
    //Sets up the file for the program
    ifstream infile;
    infile.open(FILE_NAME.c_str());
  
    //Kills the program if the file was not opened successfully.
    if(!infile)
    {
      cout << "ERROR: the file has failed to open. Check to make sure the file is in";
      cout << " the appropriate directory, and that it is named correctly." << endl;
      exit(EXIT_FAILURE);
    }

    // Prints the headers in advance
    cout << "==========================================================================" << endl;
    cout << "                Welcome to the Hurricane Database Program!" << endl;
    cout << "==========================================================================" << endl
         << endl;

    cout << "Please wait while the database is being initialized..." << endl
	 << endl;

    cout << " All Storms By Name" << endl;
    cout << " ------------------" << endl;

    //The file begins to be read here.
    
    while (infile >> hurricanes[numHurricanes].rank)
    {
      getline (infile, hurricanes[numHurricanes].name); //Fetches the name
      getline (infile, hurricanes[numHurricanes].stateCode); //Fetches the state

      infile >> hurricanes[numHurricanes].year   //Fetches year, cat and damages from 3rd line
	     >> hurricanes[numHurricanes].category
	     >> hurricanes[numHurricanes].damage;
      
      numHurricanes++;  //Counts the number of hurricanes for later use
    }
    
    infile.clear();
    infile.close();

    //Calls the function to sort the hurricanes in aplhabetical order
    SortStorms (numHurricanes, hurricanes);

    //Prints the storm names
    for (int i = 0; i < numHurricanes; i++)
    {
      cout << hurricanes[i].name << endl;
    }
    cout << endl;


    printMenu(); 	//Calls the function to show the menu
    cin >> userChoice;  //Allows for user input

    

    while (userChoice != 3) //Lets the user use the menu until they choose to quit
    {
      if (userChoice == 1)
      {
        choiceOne(hurricanes, numHurricanes);  //Calls the function for choice 1
      }
      else if (userChoice == 2)
      {
        choiceTwo(hurricanes, numHurricanes);  //Calls the function for choice 2
      }
      else  //Handles invalid menu choices
      {
        cout << "That is an invalid menu option! Please try";
        cout << " again." << endl << endl;
      } 
      
      printMenu(); 	 //Prints the menu again, to prepare for the next loop
      cin >> userChoice; //Fetches the next user choice
    }

    cout << "Thanks for using the Hurricane Database Program!" << endl;
    return (EXIT_SUCCESS);
}

/* ========================================================================= */

//Sorts an array of hurricanes into alphabetical order using the selection
//sort algorithm

void SortStorms (int numHurris, StormList hurricanes)
{
  int start,        // index to first value in unsorted portion
      smallest,     // index to smallest value in unsorted portion
      current;      // used to scan array for "smallest" value

  Hurri tempStorm;    // temporary storage for value during a swap

  for (start = 0; start < (numHurris - 1); start++)
  {
      smallest = start;

      // scan unsorted part of array to find smallest title
      for (current = (start + 1); current < numHurris; current++ )
      {
          if (hurricanes[current].name < hurricanes[smallest].name)
             smallest = current;
      }

      // perform one exchange of book records if necessary
      if (smallest != start)
      {
          tempStorm = hurricanes[start];
          hurricanes[start] = hurricanes[smallest];
          hurricanes[smallest] = tempStorm;
      }
  }

}

//Prints the menu displaying user choices

void printMenu ()
{
  cout << "Choose an option from the following menu: " << endl;
  cout << "(1): Display a particular storm given its name" << endl;
  cout << "(2): Display all storm names in a particular category" << endl;
  cout << "(3): Quit the program" << endl
       << endl;
 
  cout << "Enter your menu choice: ";
}

//Handles user choice 1

void choiceOne (StormList hurricanes, int length)
{
  string stormName; //The name the user is searching for
    cout << "Enter the name of the storm you wish to see";
    cout << " (watch your spelling!): ";
    cin >> stormName;
    cout << endl;
    StringToLower (stormName); //Ensures the name is in lowercase

    cout << stormName;

    //Searches for the user's choice
    for (int i = 0; i < length ; i++)
    {
      if (hurricanes[i].name.compare(stormName) == 0)
      {
        //Prints the information for the hurricane entered
        cout << "Rank: " << hurricanes[i].rank << endl;
        cout << "Name: " << hurricanes[i].name << endl;
        cout << "Locations: " << hurricanes[i].stateCode << endl;
        cout << "Year: " << hurricanes[i].year << endl;
        cout << "Category: " << hurricanes[i].category << endl;
        cout << fixed << "Cost: " << hurricanes[i].damage << 10 << endl;
      }
    }   
}

//Handles user choice 2
     
void choiceTwo (StormList hurricanes, int length)
{
  int cat;  //The selected category
 
  cout << "Enter a category between 0 and 5: ";
  cin >> cat;
  cout << endl;

  //Checks for incorrect input
  while (cat < 0 || cat > 5)
  {
    cout << "Sorry, invalid input. Please try again."<< endl
         << endl;

    cout << "Enter a category between 0 and 5: ";
    cin >> cat;
    cout << endl;
  }

  //Prints the header in advance
  cout << " Storms in Category " << cat << endl;
  cout << " ==================== " << endl;

  //Searches for any hurricanes in the given category
  for (int i = 0; i < length ; i++)
  {
    if (hurricanes[i].category == cat)
    {
      cout << hurricanes[i].name << endl; //Prints each name in the cat
    }
  }

  cout << endl;
}

//converts the string to lowercase

void StringToLower (string& s)
{
    int slen = static_cast<int>(s.length()); //length of the string

    for (int i = 0; i < slen; i++)
      s[i] = tolower(s[i]);
}
/* ========================================================================== */ 
/*                      E N D   O F   P R O G R A M                           */
/* ========================================================================== */

