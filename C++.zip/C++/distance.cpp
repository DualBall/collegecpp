//--------------- DISTANCE.CPP ---------------
// The class definition for distances.
//

#include <iostream>
#include "distance.h"

using namespace std;

//Constructs the Distance object with 0 distance
Distance::Distance()
{
   inches = 0;
   feet = 0;
   yards = 0;
   miles = 0;
}

//Constructs the Distance object with all distance values
Distance::Distance(int m, int y, int f, int i)
{
   //Checks for negative values
   if ((m > 0) || (y > 0) || (f > 0) || (i > 0))
   { 
     //Sets the initial values
     miles = m;
     yards = y;
     feet = f;
     inches = i;

     //Converts the values in the proper order
     checkInches();
     checkFeet();
     checkYards();
   }
   else
   {
     inches = 0;
     feet = 0;
     yards = 0;
     miles = 0;
  }
}

Distance::Distance(int i)
{
   if (i > 0)
   {
      inches = i;

      //Converts the values in the proper order
      checkInches();
      checkFeet();
      checkYards();
   }
   else
   {
     inches = 0; 
     feet = 0;
     yards = 0;
     miles = 0;
  }
}

//Member Functions

//Converts inches to feet as necessary
void Distance::checkInches()
{
   if (inches >= 12)
   {
      feet = (inches / 12);
      inches %= 12;
   }
}

//Converts feet to yards as necessary
void Distance::checkFeet()
{
   if (feet >= 3)
   {
      yards = (feet / 3);
      feet %= 3;
   }
}

//Converts yards to miles as necessary
void Distance::checkYards()
{
   if (yards >= 1760)
   {
      miles = (yards / 1760);
      yards %= 1760;
   }
}

//Operator Overloads

//overloads printing
ostream& operator<<(ostream& s, const Distance& d)
{
   s << "(";

   //checks for values as necessary
   if (d.miles > 0)
      s << d.miles << "m ";
   if (d.yards > 0)
      s << d.yards << "y ";
   if (d.feet > 0)
      s << d.feet << "' ";
   
   //prints inches regardless of value
   s << d.inches << "'')";

   return s;
}

//overloads input
istream& operator>>(istream& s, Distance& d)
{
   //sets up temporary variables as necessary
   char temp;
   int m, y, f, i;

   //reads in input
   s >> m >> temp >> y >> temp >> f >> temp >> i;
   
  //Checks for negatives and converts ((borrowed from constructor)
  if ((m >= 0) && (y >= 0) && (f >= 0) && (i >= 0))
   {
     //Sets the initial values
     d.miles = m;
     d.yards = y;
     d.feet = f;
     d.inches = i;

     //Converts the values in the proper order
     d.checkInches();
     d.checkFeet();
     d.checkYards();
   }
   else
      d.inches = 0;

   //return s;
}

//overloads addition
Distance operator+ (const Distance& d1, const Distance& d2)
{
   //adds values together
   int m = d1.miles + d2.miles;
   int y = d1.yards + d2.yards;
   int f = d1.feet + d2.feet;
   int i = d1.inches + d2.inches;

   //Checks values in order
   //Borrows code from check methods, as the actual methods
   //cannot be used here (perhaps change the methods later?)
   if (i >= 12)
   {
      f = (i / 12);
      i %= 12;
   }

   if (f >= 3)   
   {
      y = (f / 3);  
      f %= 3;   
   }
   
   if (y >= 1760)
   {
      m = (y / 1760);
      y %= 1760;
   }
  
   return Distance(m, y, f, i);
   
}

//overloads addition        
Distance operator- (const Distance& d1, const Distance& d2)
{
   //subtracts values with error checking
   int m = d1.miles - d2.miles;
   int y = d1.yards - d2.yards;
   int f = d1.feet - d2.feet;         
   int i = d1.inches - d2.inches;

   //Checks values in order
   //Borrows code from check methods, as the actual methods
   //cannot be used here (perhaps change the methods later?)
   //if ((m > 0) || (y > 0) || (f > 0) || (i > 0))
   //{
     if (i >= 12)  
     {
        f = (i / 12);      
        i %= 12;    
     }

     if (f >= 3)
     {
        y = (f / 3);
        f %= 3;
     }                 

     if (y >= 1760)
     {
        m = (y / 1760);
        y %= 1760;
     } 
   //}
   //else
      //i = 0;

   return Distance(m, y, f, i); 
}     

Distance operator* (const Distance& d1, const Distance& d2)
{  
   //multiplies values together
   int m = d1.miles * d2.miles;
   int y = d1.yards * d2.yards;
   int f = d1.feet * d2.feet;
   int i = d1.inches * d2.inches;
  
   //Checks values in order    
   //Borrows code from check methods, as the actual methods
   //cannot be used here (perhaps change the methods later?)
   if (i >= 12)
   {                
      f = (i / 12);
      i %= 12;
   }

   if (f >= 3)                 
   {
      y = (f / 3);               
      f %= 3;
   }

   if (y >= 1760)
   {
      m = (y / 1760);
      y %= 1760;
   }  

   return Distance(m, y, f, i);
}

bool operator == (const Distance& d1, const Distance& d2)
{
   return ((d1.miles == d2.miles) && (d1.yards == d2.yards) && (d1.feet == d2.feet) && (d1.inches == d2.inches));
}

bool operator != (const Distance& d1, const Distance& d2)
{
   return ((d1.miles != d2.miles) && (d1.yards != d2.yards) && (d1.feet != d2.feet) && (d1.inches != d2.inches));
}

bool operator < (const Distance& d1, const Distance& d2)
{
   return ((d1.miles < d2.miles) && (d1.yards < d2.yards) && (d1.feet < d2.feet) && (d1.inches < d2.inches));
}

bool operator > (const Distance& d1, const Distance& d2)
{
   return ((d1.miles > d2.miles) && (d1.yards > d2.yards) && (d1.feet > d2.feet) && (d1.inches > d2.inches));
}

bool operator <= (const Distance& d1, const Distance& d2)
{
   return ((d1.miles <= d2.miles) && (d1.yards <= d2.yards) && (d1.feet <= d2.feet) && (d1.inches <= d2.inches));
}

bool operator >= (const Distance& d1, const Distance& d2)
{
   return ((d1.miles >= d2.miles) && (d1.yards >= d2.yards) && (d1.feet >= d2.feet) && (d1.inches >= d2.inches));   
}

Distance& Distance::operator++()  //pre-fix increment
{
   inches += 1;		// increment the inches
   //Checks for conversions
   checkInches();
   checkFeet();
   checkYards();

   return *this;		// return reference to calling object
}

Distance Distance::operator++(int)	// post-fix increment
{
   Distance temp = *this;	// copy current object to temp
   inches += 1;		// increment
   //Checks for conversions
   checkInches();
   checkFeet();
   checkYards();

   return temp;			// return OLD value
}

Distance& Distance::operator--()	// pre-fix decrement
{
   inches -= 1;		// decrement the inches
   
   //Checks for conversions using nested if statements
   if (inches < 0)
   {
      if (feet < 0)
      {
         if (yards < 0)
         {
            if (miles <= 0)
               inches += 1; //reverts the change if distance is 0

            miles -= 1; //converts miles back to yards if necessary
            yards += 1760;
         }
         yards -= 1; //converts yards back to feet if necessary
         feet += 3;
      }
      feet -= 1; //converts feet back to inches if necessary
      inches += 12;
    }
     
   return *this;		// return reference to calling object
}

Distance Distance::operator--(int)
{
   Distance temp = *this;	// copy current object to temp
    inches -= 1;         // decrement the inches

   //Checks for conversions using nested if statements
   if (inches < 0)
   {
      if (feet < 0)
      {
         if (yards < 0)
         {
            if (miles <= 0)
               inches += 1; //reverts the change if distance is 0

            miles -= 1; //converts miles back to yards if necessary
            yards += 1760;
         }
         yards -= 1; //converts yards back to feet if necessary
         feet += 3;
      }
      feet -= 1; //converts feet back to inches if necessary
      inches += 12;
    }

   return temp;			// return OLD value
}
