//--------------- DISTANCE.H ---------------

#include <iostream>
using namespace std;

class Distance
{
   //Friend operator overloads

   friend ostream& operator << (ostream& s, const Distance& d);
   friend istream& operator >> (istream& s, Distance& d);

   friend Distance operator + (const Distance& d1, const Distance& d2);
   friend Distance operator - (const Distance& d1, const Distance& d2);
   friend Distance operator * (const Distance& d1, const Distance& d2);

   friend bool operator == (const Distance& d1, const Distance& d2);
   friend bool operator != (const Distance& d1, const Distance& d2);
   friend bool operator < (const Distance& d1, const Distance& d2);
   friend bool operator > (const Distance& d1, const Distance& d2);
   friend bool operator <= (const Distance& d1, const Distance& d2);
   friend bool operator >= (const Distance& d1, const Distance& d2);

public:
   //Default constructor
   Distance();

   //4 number constructor
   Distance(int m, int y, int f, int i);

   //Inch-based constructor
   Distance(int i);

   // increment and decrement operations
   Distance& operator++();	// prefix increment
   Distance operator++(int);	// postfix increment
   Distance& operator--();	// prefix decrement
   Distance operator--(int);	// postfix decrement

   //unit conversion
   void checkYards();
   void checkFeet();
   void checkInches();

private:
   int miles;   //the mile count                  
   int yards;  //the yard count
   int feet;   //the foot count
   int inches; //the inch count
};

