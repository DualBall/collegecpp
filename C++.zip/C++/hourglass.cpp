//--------------- HOURGLASS.CPP ---------------
// The class definition for the hourglass.
//

#include <iostream>
#include <iomanip>
#include <cmath>
#include "hourglass.h"

using namespace std;

//Constructs the Hourglass object
Hourglass::Hourglass(int s, char b, char f)
{
   //Ensures the size is between 1 and 39
   size = s;

   if (size > 39)
   {
     size = 39;
   }
   else if (size < 1)
   {
     size = 1;
   }
   
   //Calls functions to ensure characters are in valid ASCII range
   SetBorder(b);
   SetFill(f);
}

//Returns the length of each side
int Hourglass::GetSize() const
{
   return size;
}

//Returns the perimeter of the hourglass
int Hourglass::Perimeter() const
{
   return size * 6;
}

//Returns the area of the hourglass
double Hourglass::Area() const
{
   return ((sqrt(3)/4) * pow(size, 2)) * 2;
}

//Increments size
void Hourglass::Grow()
{
   if (size + 1 <=39)
     size++;
}

//Decrements size
void Hourglass::Shrink()
{
   if (size - 1 >= 1)
     size--;
}

//Sets border character; returns to default if out of range
void Hourglass::SetBorder(char setB)
{
   if (int(setB) < 33 || int(setB) > 126)
      border = '#';
   else
      border = setB;
}

//Sets fill character; returns to default if out of range
void Hourglass::SetFill(char setF)
{             
   if (int(setF) < 33 || int(setF) > 126)
      fill = '*';
   else
      fill = setF;
}

//Draws the hourglass
void Hourglass::Draw()
{
   //Draws top border
   for(int i = 0; i < size; i++)
   {
     cout << border << " ";
   }
   
   cout << endl;

   //Draws the top half of the hourglass using nested loops
   for(int i = 1; i < size - 1; i++)
   {
     //creates empty lines
     cout << endl;
     
     //prints whitespace in front of the left side
     for(int j = i; j == 0; j--)
       cout << " ";

     //prints the left border
     cout << border << " ";

     //prints the inside of the hourglass
     for (int j = (size - 2) - i; j == 0; j--)
        cout << fill << " ";

     //prints the right border
     cout << border << endl;
   }

   //Draws the midde of the hourglass
   cout << border << endl;

   //Draws the bottom half of the hourglass
   for(int i = size - 1; i > 1; i--) 
   {
     //creates empty lines
     cout << endl;

     //prints whitespace in front of the left side
     for(int j = i; j == 0; j--)
       cout << " ";

     //prints the left border
     cout << border << " ";

     //prints the inside of the hourglass
     for (int j = 0 + i; j == 5; j++)
        cout << fill << " ";

     //prints the right border
     cout << border << endl;
   }

   //Draws bottom border
   for(int i = 0; i < size; i++)
     cout << border << " ";
}

void Hourglass::Summary()
{
   //Prints information regarding this hourglass
   cout << "Size of hourglass's side = " << size << " units." << endl;
   cout << "Perimeter of hourglass = " << Perimeter() << " units." << endl;
   cout << setprecision(2) << "Area of hourglass = " << Area() << " units." << endl;
   cout << "Hourglass looks like:" << endl;
   Draw();   
}
