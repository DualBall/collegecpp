//--------------- HOURGLASS.H ---------------

class Hourglass
{
public:
   //Constructor that requires an input for the first parameter
   //Size = length of a side, fill = the "sand" of the hourglass
   Hourglass(int s, char b = '#', char f = '*');

   // accessors
   int GetSize() const;
   int Perimeter() const;
   double Area() const;

   // mutators
   void Grow();
   void Shrink();
   
   void SetBorder(char setB);
   void SetFill(char setF);
  
   //display functions
   void Draw();
   void Summary();

private:
   int size;   //length of a side                  
   char border;  //The character that makes up the border of the hourglass
   char fill;  //The character that makes up the sand of the hourglass
};

