//----------------- MENU.CPP -----------------
// Test program and general support functions for StudentList
// Bugtesting statements are pointed out appropriately

#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>
#include "studentlist.h"
#include "student.h"

using namespace std;

void ShowMenu()
// Display the main program menu.
{
   cout << "\n\t\t*** Student List menu ***";
   cout << "\n\tI: \tImport students from a file";
   cout << "\n\tS: \tShow student list (brief)";
   cout << "\n\tE: \tExport a grade report (to file)";
   cout << "\n\tO: \tsOrt student list";
   cout << "\n\tM: \tShow this Menu";
   cout << "\n\tQ: \tQuit Program";
   cout << "\n\nPlease type an option, and press Enter.";
}

char GetAChar(const char* promptString)
// Prompt the user and get a single character,
// discarding the Return character.
// Used in GetCommand.
{
   char response;			// the char to be returned
	
   cout << promptString;		// Prompt the user
   cin >> response;			// Get a char,
   response = toupper(response);	// and convert it to uppercase
   cin.get();				// Discard newline char from input.
   return response;
}

bool Legal(char c)
// Determine if a particular character, c, corresponds
// to a legal menu command.  Returns true if legal, false if not.
// Used in GetCommand.
{
	return	((c == 'I') || (c == 'S') || (c == 'E') || (c == 'M') ||
			 (c == 'O') || (c == 'Q'));
}

char GetCommand()
// Prompts the user for a menu command until a legal 
// command character is entered.  Return the command character.
// Calls GetAChar, Legal, ShowMenu.
{
   char cmd = GetAChar("\n\n>");	// Get a command character.
	
   while (!Legal(cmd))		// As long as it's not a legal command,
   {				// display menu and try again.
	cout << "\nIllegal command, please try again . . .";
	ShowMenu();
	cmd = GetAChar("\n\n>");
   }
   return cmd;
}

int main()
{
   /*
   //Beginning of testing section

   //Sets grades for students
   int b1G [5] = {85, 90, 78, 85, 89};
   int t1G [3] = {85, 72, 95};
   int c1G [9] = {90, 82, 85, 96, 100, 88, 85, 91, 97};

   //Sets strings for names so that they won't be c-strings
   string b1L("Finklebottom");
   string b1F("Joe");
   //cout << b1L << b1F << endl;  //tests strings

   //cout << "Test One" << endl;    //Testing

   //Declares objects for function testing
   Biology b1(b1L, b1F, b1G);
   Theater t1("Dipwart", "Marvin", t1G);
   Comp c1("Squarepants", "Spongebob", c1G);

   //cout << "Test Two" << endl;    //Testing

   //Function testing
   cout << b1.GetLastName() << b1.GetFirstName() << b1.GetCourse() << endl;
   cout << b1.GetFinal();

   cout << t1.GetLastName() << t1.GetFirstName() << t1.GetCourse() << endl;
   cout << t1.GetFinal();

   cout << c1.GetLastName() << c1.GetFirstName() << c1.GetCourse() << endl;
   cout << c1.GetFinal();

   //End of testing section
   */
   char filename[30];             //Variable for filenames

   StudentList s;	          // Create and initialize a new student list.
   ShowMenu();		          // Display the menu.
	
   char command;			// menu command entered by user
   do
   {
	command = GetCommand();		// Retrieve a command.
	switch (command)
	{
	   case 'I': 
           cout << "\tEnter filename: ";
           cin.get(filename, 30);
           s.ImportFile(filename);
           break ;

           case 'S': 
           s.ShowList();
	   break;

           
	   case 'E':
           cout << "\tEnter filename: ";
           cin.getline(filename, 30);
           s.CreateReportFile(filename); 
           break;
           	   
           case 'O': 
           s.SortList();
           cout << "The list has been sorted!" << endl;
           break;

           case 'M': ShowMenu();
           break;
	}

     //Asks for the next command until Q is selected
     if (command != 'Q')
     {
        cout << " Please enter your next command: ";
     }
   } while (command != 'Q');

   cout << "Thank you for using the StudentList!";
   return 0;
}
