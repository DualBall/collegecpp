#include <iostream>
#include <cctype>
#include <cmath>
#include <cstring>
#include "myint.h"

using namespace std;

//Code written by Dr Myers of the FSU Computer Science Department
int MyInt::C2I(char c)
// converts character into integer (returns -1 for error)
{
   if (c < '0' || c > '9')	return -1;	// error
   return (c - '0');				// success
}

//Code written by Dr Myers of the FSU Computer Science Department           
char MyInt::I2C(int x)
// converts single digit integer into character (returns '\0' for error)
{
   if (x < 0 || x > 9)		return '\0';	// error
   return (static_cast<char>(x) + '0'); 	// success
}

//Various cout statements which are commented out are littered throughout this code.
//These statements are designed to provide my process with visibility.
//They are for bugtesting only!

//---------- Operator Overloads ---------
istream& operator >> (istream& s, MyInt& M)
// read in data through overloaded >> operator
{
   //Variable to read in integers for conversion
   int currInt;

   //Variable to iterate the do-while loop coming up
   int i = 0;
   
   //Variable to read in spaces that shouldn't be extracted
   char space;

   //Eliminates any whitespace preceding the number
   while (isspace(s.peek()))
   {
      s.get(space);
   }

   //Reads in the integer until a non-digit is found
   do {
      s.get(M.digits[i]);
      i++;
      M.currentSize++;
      //Grows the array if necessary
      if (M.currentSize == M.maxSize)
         M.Grow();  

      //cout << "test a" << endl;
   } while (isdigit(s.peek()));
   
   return s;
}


ostream& operator << (ostream& s, const MyInt & M)
// print an integer using the overloaded << operator
{
   //cout << "Bruh";
   for (int i = 0; i < strlen(M.digits); i++)
   {
      //Ensures that only digits are printed (prevents weird printing errors)
      if (isdigit(M.digits[i]))
	s << M.digits[i];

   }
   return s;
}

//The comparison operators for MyInt that do most of the work
bool operator< (const MyInt& x, const MyInt& y)
{
   //Checks if one MyInt is longer than the other
   //If not, iterates as necessary before determining which is larger
   int i = 0;
   if (strlen(x.digits) < strlen(y.digits))
      return true;
   else
   {
      do {
         i++;
      } while (x.digits[i] == y.digits[i]);
   }
   return x.digits[i] < y.digits[i];
}

bool operator<= (const MyInt& x, const MyInt& y)
{
   //Checks if one MyInt is longer than or equal to the other
   //If not, iterates as necessary before determining which is larger
   int i = 0;
   
   if (strlen(x.digits) < strlen(y.digits))
      return true;
   else if (x == y)
      return true;
   else
   {
      do {
         i++;
      } while (x.digits[i] == y.digits[i]);
   }
   
   return x.digits[i] < y.digits[i];
}

bool operator== (const MyInt& x, const MyInt& y)
{
   //Checks if one MyInt length does not the other
   //If not, iterates as necessary before determining which is larger
   int i = 0;
   if (strlen(x.digits) != strlen(y.digits))
      return false;
   else
   {
      for (int i = 0; i < strlen(x.digits); i++)
      {
         if (x.digits[i] != y.digits[i])
            return false;
      }
      return true;
   }
}

//Comparison operators that rely on the others
bool operator> (const MyInt& x, const MyInt& y)
{
   return !(x < y);
}

bool operator>= (const MyInt& x, const MyInt& y)
{
   return !(x <= y);
}

bool operator!= (const MyInt& x, const MyInt& y)
{
   return !(x == y);
}

MyInt operator+ (const MyInt& x, const MyInt& y)
{
   int tackOn = 0;              //Used to carry ones
   //Variables for the for loop (i is the index of the larger array, and vice versa)
   int currInt, i, j; 

   //Stores the size of the shorter MyInt (or the size of both if equal)
   //Calls on conditional operators to make things easier
   if (x < y || x == y)
   {
      i = strlen(y.digits) - 1;
      j = strlen(x.digits) - 1;
   }
   else
   {
      i = strlen(x.digits) - 1;
      j = strlen(y.digits) - 1;
   }

   //Prepares c-string to store sum (should be one slot bigger than larger c-string)
   char* newDigits = new char[i + 2];
   
   //Adds up the two MyInts, character by character, from the right until the front of j
   for (j; j >= 0; j--)
   {
      //Mimics the if-else above to determine where to use indexes
      //Borrows code from C2I since I had trouble using it here
      if (x < y || x == y)
      {
         currInt = (x.digits[j] + '0') + (y.digits[i] + '0') + tackOn;
         cout << (x.digits[j] + '0') << " ";
      }
      else
      {
         currInt = (x.digits[i] + '0') + (y.digits[j] + '0') + tackOn;
         cout << (x.digits[i] + '0') << " ";
      }

      //Prepares to carry the one if necessary
      if (currInt >= 10)
      {
         cout << "test b";
         tackOn = 1;
         currInt -= 10;
      }
      else
      {
         cout << "test c";
         tackOn = 0;
      }
      
      //Borrows code from I2C
      newDigits[i] = (static_cast<char>(currInt) + '0');

      i--;         //Iterates the larger array
   }

   //Continues carrying the one through the larger array, if necessary
   //This should never happen if the c-strings are of equal length
   for (i; i > 0 || tackOn != 0; i--)
   {
      if (x < y)
         currInt = (y.digits[i] + '0') + tackOn;
      else
         currInt = (y.digits[j] + '0') + tackOn;
 
      //Prepares to carry the one if necessary
      if (currInt >= 10)
      {
         //cout << "test b";
         tackOn = 1;
         currInt -= 10;
      }
      else
      {
         //cout << "test c";
         tackOn = 0;
      }

      //Borrows code from I2C
      newDigits[i] = (static_cast<char>(currInt) + '0');
   }
   
   //Sets the front to one if there is still a one to be carried.
   //If not, sets the front to 0 so as not to affect the number any more.
   if (tackOn == 1)
      newDigits[0] = '1';
   else
      newDigits[0] = '0';

   //Returns the new array
   return MyInt(newDigits);
}  

//Increment overloads
MyInt& MyInt::operator++()  //pre-fix increment
{
   int num = C2I(digits[strlen(digits)-1]);
   int tackOn = 0;              //Used to handle carrying ones
 
   //Checks to see if the one should be carried
   if (num + 1 >= 10)
   {
      tackOn = 1;

      //Carries the one as many times as necessary
      for (int i = (strlen(digits)-2); tackOn != 0 && i >= 0; i--)
      {
         //cout << "test b";
         num = C2I(digits[i]);               
         num += 1;
         //cout << num;
         if (num < 10)
         {  
            tackOn = 0;
            digits [i] = I2C(num);
         }
      }
  
      num = 0;                           
   }
   else 
      num += 1;  

   //Sets the end of the number equal to num, which should be corret
   //regardless of what num ended up being    
   digits[strlen(digits)-1] = I2C(num);

   return *this;
}



MyInt MyInt::operator++(int)	// post-fix increment
{
   MyInt temp = *this;
   int num = C2I(digits[strlen(digits)-1]);
   int tackOn = 0;              //Used to handle carrying ones
 
   //Checks to see if the one should be carried
   if (num + 1 >= 10)
   {
      tackOn = 1;
      //cout << "test a";
      //Carries the one as many times as necessary
      for (int i = (strlen(digits)-2); tackOn != 0 && i >= 0; i--)
      {
         //cout << "test b";
         //cout << C2I(digits[i]);
         num = C2I(digits[i]);
         num += 1;
         //cout << num;
         if (num < 10)
         {
            tackOn = 0;
            digits [i] = I2C(num);
         }
      }
  
      num = 0;
   }
   else
      num += 1;
   
   //Sets the end of the number equal to num, which should be corret
   //regardless of what num ended up being
   digits[strlen(digits)-1] = I2C(num);

   return temp;
}
//---------- Member functions ----------

//First constructor; converts a normal int to a MyInt 
MyInt::MyInt(int n)			
{ 
   maxSize = 5; 
   currentSize = 0; 
   digits = new char[maxSize];

   //Checks for negative input
   if (n < 0)
   {
      digits[0] = '0';
      //cout << digits[0];
   }
   else 
   {
     //converts integer to digits, then to characters
     for (int i = 0; i < floor(log10(n)); i++)
     {
        digits[i] = I2C((static_cast<int>(floor(n/((10)^i)))) % 10);
        currentSize++;
        //Grows the array if necessary
        if (currentSize == maxSize)
           Grow();
        //cout << digits[i];
     }
   //cout << endl;
   }

   //Sets digits equal to 0 if there is still nothing in it
   //This covers MyInts constructed with no values put in
   if (!(isdigit(digits[0])))
      digits[0] = '0';
}

//Second constructor; converts a c-string to a MyInt
MyInt::MyInt(const char * c)
{
   //cout << "test 0" << endl;
   maxSize = 5;
   currentSize = 0;
   digits = new char[maxSize];

   bool isValid = true;

   //Checks if any chars are invalid
   for (int i = 0; i < strlen(c) - 1; i++)
   {
      //Test if statement
      //if(isdigit(c[i]))
      //   cout << "Nice";

      if (!(isdigit(c[i])))
      {
         digits[0] = '0';
         //cout << digits[0];
         isValid = false;
      }
   }

   if (isValid)
   {
     //sets digits equal to the c string input
     for (int i = 0; i < strlen(c) + 1; i++)
     {
        digits [i] = c[i];
        currentSize++;
        //Grows the array if necessary
        if (currentSize == maxSize)
           Grow();
        //cout << digits[i];
     }
     //cout << endl;
   }
}

//Destructor for dynamic char array
MyInt::~MyInt()
{
   delete [] digits;
}
//Copy Constructor for MyInt
MyInt::MyInt(const MyInt & D)
{
   maxSize = D.maxSize;
   currentSize = D.currentSize;

   // allocate new array of digits
   digits = new char[maxSize];	

   // copy the list over from D
   for (int i = 0; i < currentSize; i++)
	digits[i] = D.digits[i];
}

//asignment operator
MyInt& MyInt::operator= (const MyInt & D)
{
   if (this != &D)		// only make the copy if the original is
   {				//  not this same object

      delete [] digits;

      maxSize = D.maxSize;
      currentSize = D.currentSize;
      digits = new char[maxSize];
      for (int i = 0; i < currentSize; i++)
	digits[i] = D.digits[i];
   }

   return *this;		// return this object
}

void MyInt::Grow()
// Double the size of the digit list
// by creating a new, larger array of entries
// and changing the directory's pointer to refer to
// this new array.
{
   maxSize = currentSize + 5;			// Determine a new size.
   char* newDigits = new char[maxSize];
	
   for (int i = 0; i < currentSize; i++)	// Copy each entry into
	newDigits[i] = digits[i];		// the new array.
		
   delete digits;			// Remove the old array
   digits = newDigits;			// Point old name to new array.
}
