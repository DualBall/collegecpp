//----------------- PALINDROME.CPP -----------------
// Test program and general support functions for StudentList
// Bugtesting statements are pointed out appropriately

#include <iostream>
#include <cstring>
#include <cctype>
#include "stack.h"
#include "list.h"

using namespace std;

int main()
{
   char input[100];         //Used to store input
   char lower[100];         //Variable used to store results of tolower
   Stack< char > refined;   //Sets up a list (stack) for the edited input
   char reversed[100];      //Variable used to read in reversed string

   //Reads in user input
   cout << "Please enter a string: ";
   cin.getline(input, 100);

   //Edits user input
   for (int i = 0; i < strlen(input); i++)
   {
      if (isalpha(input[i]))
         lower[i] = tolower(input[i]);
   }

   //Pushes user input into the stack
   for (int i = 0; i < strlen(lower); i++)
        refined.push(lower[i]); 

   //Pops the string back out of the stack to reverse it
   for (int i = 0; i < strlen(lower); i++)
         refined.pop(reversed[i]);

   cout << "\nThe string \"" << input << "\"  ";
   
    if (strcmp(lower, reversed) == 0)
       cout << "is a palindrome.\n\n";
    else
        cout << "was not a palindrome.\n\n";

   return 0;
}

