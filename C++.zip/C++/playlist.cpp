//----------------- playlist.cpp -----------------
// Definitions for class Playlist

#include <iostream>
#include <cstring>		// for strcmp
#include <iomanip>
#include <cctype>
#include "playlist.h"

using namespace std;

Playlist::Playlist()			
// Set up empty playlist.
{ 
   maxSize = 5; 
   currentSize = 0; 
   songList = new Song[maxSize];
}

Playlist::~Playlist()
// This destructor function for class Playlist
// deallocates the playlist's list of Song objects.
{
   delete [] songList;
}

//The middleman between the Song::Set function and the menu
void Playlist::Add(const char* t, const char* a, Style st, int sz)
// Insert a new song into the playlist.
{
   if (currentSize == maxSize)		// If the directory is full, grow it.
 	Grow();
   songList[currentSize++].Set(t, a, st, sz);	// read new entry.
}

void Playlist::Find(char aName[35]) const
{
   int thisName = FindSong(aName);	// Locate the song in the playlist.
   char thisArtist[21];
	
   //Checks if a song was found
   if (thisName != -1)
   {
      cout << songList[thisName]; //display the song
   }
   //Checks if the name is for an artist instead
   //If so, prints all songs by that artist
   else
   {
      thisName = FindArtist(aName);
      if (thisName != -1)
      {
        strcpy(thisArtist, songList[thisName].GetArtist());
        for (int i = 0; i < currentSize; i++)
        {   
           if (strcmp(songList[i].GetArtist(), thisArtist) == 0)
              cout << songList[thisName];
        } 
      }
      else
         cout << aName << "not found in playlist; please try again. \n";
   }
}

void Playlist::Delete(char aName[35])
{
   int thisSong = FindSong(aName);	// Locate the song in the playlist.
	
   if (thisSong == -1)
	cout << aName << " not found in playlist; please try again.";
   else
   {
	// Shift each succeeding element "down" one position in the
	// Song array, thereby deleting the desired song.
	for (int j = thisSong + 1; j < currentSize; j++)
		songList[j - 1] = songList[j];
			
	currentSize--;		// Decrement the current number of songs.
      cout << "Song deleted successfully. Returning to menu... \n";
   }
}

void Playlist::Show() const
{
   double storage = FindStorage() / 1000.0;
   if (currentSize == 0)
   {
	cout << "\nCurrent playlist is empty.\n";
	return;
   }
	
   // Display a header.
   cout << "\n\tTitle\t\tArtist\t\tStyle\t\tSize (MB)\n\n";
	
   //Print songs
   for (int i = 0; i < currentSize; i++)	
	cout << songList[i];

   //Displays total songs and size
   cout << "\nTotal songs in playlist: " << currentSize << " songs. \n";
   cout << "Total size of playlist: " << setprecision(2) << storage << " MB";
}

void Playlist::ShowCat(Style category) const
{
   if (currentSize == 0)
   {
        cout << "\nCurrent playlist is empty.\n";
        return;
   }

   // Display a header.
   cout << "\n\tTitle\t\tArtist\t\tStyle\t\tSize (MB)\n\n";

   //Print songs
   for (int i = 0; i < currentSize; i++)
   {
      if (songList[i].GetCategory() == category);
        cout << songList[i];
   }
}

void Playlist::ShowStorage()
{
   cout << FindStorage() << " kb of content in this playlist.";
}

void Playlist::Grow()
// Double the size of the playlist
// by creating a new, larger array of entries
// and changing the directory's pointer to refer to
// this new array.
{
   maxSize = currentSize + 5;			// Determine a new size.
   Song* newList = new Song[maxSize];		// Allocate a new array.
	
   for (int i = 0; i < currentSize; i++)	// Copy each entry into
	newList[i] = songList[i];		// the new array.
		
   delete [] songList;			// Remove the old array
   songList = newList;			// Point old name to new array.
}

int Playlist::FindSong(char* aName) const
// Locate a song in the playlist.  Returns the
// position of the song as an integer if found.
// and returns -1 if the song is not found.
{
   for (int i = 0; i < currentSize; i++)	// Look at each entry.
	if (strcmp(songList[i].GetTitle(), aName) == 0)
		return i;		// If found, return position and exit.
			
   return -1;				// Return -1 if never found.
}

int Playlist::FindArtist(char* aName) const
// Locate an artist in the playlist.  Returns the
// position of the song as an integer if found.
// and returns -1 if the song is not found.
{
   for (int i = 0; i < currentSize; i++)        // Look at each entry.  
        if (strcmp(songList[i].GetArtist(), aName) == 0)                 
                return i;               // If found, return position and exit.

   return -1;                           // Return -1 if never found.
}

int Playlist::FindStorage() const
{
   int storage = 0;
   
   for (int i = 0; i < currentSize; i++)
      storage += songList[i].GetSize();

   return storage;
}
