//----------------- playlist.h -----------------

// Declarations for class Playlist, where a directory
// is a collection of Songs, declared in "SONG.H".

#include "song.h"

class Playlist
{
public:
   Playlist();			// Set up empty playlist
   ~Playlist();		        // Deallocate the playlist.

   void Add(const char* t, const char* a, Style st, int sz);
   // Add a song to the playlist (middleman
   // between Song::Set and the menu)
   void Find(char aName[35]) const;		// Find a song in the playlist.
   void Delete(char aName[35]);		// Delete a song.
   void Show() const;           // Displays the entire playlist.
   void ShowCat(Style category) const;        // Displays songs from a category.
   void ShowStorage();          // Computes and displays total storage, in kb

private:
   int maxSize; 
   int currentSize;		// the current number of songs
   Song* songList;		// pointer to the list of songs
   void Grow();			// Increase maximum size, when required.
   int FindSong(char* aName) const;	// Return index of a song, given a name.
   int FindArtist(char* aName) const;   //Same as above, but for artists.
   int FindStorage() const;           //Find storage of playlist
};
