//--------------- SONG.CPP ---------------
// The class definition for songs.
//

#include <iostream>
#include <cstring>
#include "song.h"

using namespace std;

//Constructs the Song object
Song::Song()
{}

//Member functions

//Sets object data
void Song::Set(const char* t, const char* a, Style st, int sz)
{
   strcpy(title, t);
   strcpy(artist, a);
   category = st;
   size = sz;
}

const char* Song::GetTitle() const
{
   return title;
}

const char* Song::GetArtist() const
{
   return artist;
}

int Song::GetSize() const
{
   return size;
}
  
Style Song::GetCategory() const
{
   return category;
}

//Operator Overloads

//overloads printing
ostream& operator<<(ostream& s, const Song& d)
{
   s << d.title << "\t" <<  d.artist << "\t";
   
   if (d.category == 0)
     s << "Pop";
   else if (d.category == 1)
     s << "Rock";
   else if (d.category == 2)
     s << "Alt";
   else if (d.category == 3)
     s << "Ctry";
   else if (d.category == 4)
     s << "HH";
   else
     s << "Par";

   s << "\t" << d.size / 1000.0 << "\n";
}
