// ----------STUDENT.CPP----------
//Definitions for each type of Student
//Bugfixing statements are marked accordingly

#include <iostream>
#include <string>
#include "student.h"

using namespace std;

//Student member functions

//Default constructor
Student::Student()
{
}

//Getters
string Student::GetFirstName () const
{
   return firstName;
}

string Student::GetLastName () const
{
   return lastName;
}

string Student::GetCourse() const
{
    return course;
}

//////////////////////////////////////////////////

// Biology class member functions

//Constructor
Biology::Biology(string l, string f, int g[5])
{
   course = "Biology";

   lastName = l;
   firstName = f;
   

   //Copies the array input into grades
   for (int i = 0; i < 5; i++)
   {
      //cout << "Test A" << endl;   //Testing
      grades[i] = g[i];
      //cout << grades[i] << endl;    //Testing
   }
}

//Calculuates and returns this student's final grade
double Biology::GetFinal() const
{
   //Finds and returns total average
   return (grades[0] * 0.30) + (grades[1] * 0.15) + (grades[2] * 0.15) + (grades[3] * 0.15) + (grades[4] * 0.25);
}

//Returns the grade for the Final Exam
int Biology::GetExam() const
{
   //cout << grades[4];   //Testing
   return grades[4];
}

//////////////////////////////////////////////////

// Theater class member functions

//Constructor
Theater::Theater(string l, string f, int g[3])
{
   course = "Theater";

   lastName = l;
   firstName = f;
   
   //Copies the array input into grades
   for (int i = 0; i < 3; i++)
      grades[i] = g[i];
}

//Calculates and returns this student's final grade
double Theater::GetFinal() const
{
   //Finds and returns the total average
   return (grades[0] * 0.40) + (grades[1] * 0.25) + (grades[2] * 0.35);
}

//Returns the grade for the Final Exam        
int Theater::GetExam() const
{
   return grades[2];
} 

//////////////////////////////////////////////////

//Comp class member functions

//Constructor
Comp::Comp(string l, string f, int g[9])
{
   course = "Computer Science";

   lastName = l;
   firstName = f;

   //Copies the array input into grades
   for (int i = 0; i < 9; i++)
      grades[i] = g[i];
}

//Calculuates and returns this student's final grade double 
double Comp::GetFinal() const 
{
   double programGrades = 0.0;

   //Adds together program grades
   for (int i = 0; i < 6; i++)
      programGrades += grades[i];

   //Finds average for program grades
   programGrades /= 6.0;

   //Weights the average for program grades
   programGrades *= 0.30;

   //cout << programGrades << "  "; //Testing
   //Finds and returns total average
   return (programGrades) + (grades[6] * 0.20) + (grades[7] * 0.20) + (grades[8] * 0.30);
}

//Returns the grade for the Final Exam        
int Comp::GetExam() const
{
   return grades[8];
} 
