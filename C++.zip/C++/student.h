// ----------STUDENT.H----------
// Declarations for class Student and derived classes.  
// Student has three derived subclasses: Biology, Theater and Comp.

#include <iostream>
#include <string>
#ifndef _STUDENT_H
#define _STUDENT_H

using namespace std;

class Student
{
public:
   //Normal functions   
   string GetFirstName() const;    //getters for names and courses
   string GetLastName() const;
   string GetCourse() const;

   //Virtual functions
   virtual double GetFinal() const = 0; //sets up GetFinal for all Student types
   virtual int GetExam() const = 0;     //sets up GetExam    

protected:
   Student ();               //Default constructor
   string firstName, lastName, course; //Strings for names and courses
};

class Biology : public Student
//Biology Students
{
public:
   Biology(string l, string f, int g[5]);  //Biology Constructor

   double GetFinal() const;  //compute and return the student's  final grade
   int GetExam() const;

private:
   int grades [5];   //List of student's grades (specific to Biology)
};

class Theater : public Student
//Theater Students
{
public:
   Theater(string l, string f, int g[3]);  //Theater constructor

   double GetFinal() const;  //compute and return the student's  final grade
   int GetExam() const;
private:
   int grades [3];   //List of student's grades (specific to Biology)

};

class Comp : public Student
//Computer Science Students
{
public:           
   Comp(string l, string f, int g[9]);    //Computer Science  constructor

   double GetFinal() const;  //compute and return the student's  final grade
   int GetExam() const;
private:
   int grades [9];   //List of student's grades (specific to Biology)

};

#endif
