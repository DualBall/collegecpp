//----------------- STUDENTLIST.CPP -----------------
// Definitions for the list of Students.
// Bugtesting statements are marked accordingly.

#include <iostream>
#include <iomanip>
#include <string>
#include <fstream>
#include "studentlist.h"
#include "student.h"

using namespace std;

StudentList::StudentList()			
// Sets up empty list of students.
{ 
   size = 0;
   sList = NULL;
}

StudentList::~StudentList() 
//Destructor for the list of students
{
   //Deletes pointers first, then delets the array as a whole
   for (int i = 0; i < size; i++)
      delete sList[i];
   delete [] sList;
}

bool StudentList::ImportFile(const char* filename)
//Adds all data from the given file to the student list.
//Returns true if successful. If there is an issue regarding the filename,
//this will return false.
{
   //Prepares the file for reading
   ifstream in;
   in.open(filename);

   //Checks to make sure a file was opened successfully
   if (!in)
   {
      cout << "Invalid file. No data imported.";
      return false;
   }

   //cout << "Test 1" << endl; //Testing

   //Begins reading the file
   char junk;                //Used to throw out newlines
   string comma = ",";   //Used to parse names
   string name;              //Used to store names

   //Used to store the number of new students given at the start of the file
   int temp;
   in >> temp;
   //cout << temp << endl;     //Testing
   in.get(junk);
   
   //Variables used to pass in new data (the array is declared further down)
   string l, f, c;
   int length;

   //Reads in students
   for (int i = 0; i < temp; i++)
   {
      //Reads in names
      getline(in, name);
      l = name.substr(0, name.find(comma));
      f = name.substr(name.find(comma)+1, name.length());
      //cout << l << " " << f << endl;   //Testing
      
      //Reads in courses (and declares grade arrays)
      in >> c;
      //cout << c << endl;              //Testing

      if (c.compare("Biology") == 0)
         length = 5;
      else if (c.compare("Theater") == 0)
         length = 3;
      else if (c.compare("Computer") == 0)
      {
         length = 9;
         //Adds to the c variable, since there's a second word
         string temp;
         in >> temp;
         c.append(temp);
      }

      //Creates an array to store grades that are read in
      int g[length];

      //Reads in grades
      for (int j = 0; j < length; j++)
      {
         in >> g[j];
         //cout << g[j] << endl;  //Testing
      }

      in.get(junk);
      //cout << junk << endl;       //Testing

      //cout << "Made it through reading. " << endl; //Testing

      //Creates the new students
      Grow();
      Insert(l, f, c, g);
   }

   //Concludes the import
   in.close();
   return true;
}

void StudentList::ShowList() const
// Display the current students
{
   if (size == 0)
   {
	cout << "\nCurrent student list is empty.\n";
	return;
   }
	
   // Display a header.
   cout << setw(20) << left <<  "Last" << setw(20) << " First" << setw(20)
   << left << "Course" << endl << endl;
	
   //Prints each student
   for (int i = 0; i < size; i++)
   {
      cout << setw(20) << sList[i]->GetLastName() << setw(20) <<
      sList[i]->GetFirstName() << setw(20) << sList[i]->GetCourse() << endl;
   }
}

void StudentList::SortList() const
//Sort the current students alphabetically
{
   //Prepares variables needed for comparisons and transitions
   string name1, name2;
   Student* temp;
   int length;
   char compare1, compare2;

   //Begins sorting using a nested loop
   for (int i = 0; i < size; i++)
   {
      for (int j = 1; j < size; j++)
      {
         //Takes in last names, and checks if they're equal. If they are equal,
         //first names are used instead. (It is assumed that the first names,
         //at least, are different.)
         name1 = sList[i]->GetLastName();
         name2 = sList[j]->GetLastName();
      
         if (name1 == name2)
         {
            name1 = sList[i]->GetFirstName();
            name2 = sList[j]->GetFirstName();
         }

         //Checks to see which name is shorter, and begins comparing based on this
         if (name1.length() < name2.length())
            length = name1.length();
         else
            length = name2.length();

         //cout << name1 << " " << name2;    //Testing

         for (int k = 0; k < length; k++)
         {
            //Rearranges the strings if a name2 that comes before name1 is found. 
            //The student represented by name1 is moved down a space.
            compare1 = name1.at(k);
            compare2 = name2.at(k);
            if (islower(compare1))
               compare1 -= 32;
            if (islower(compare2))
               compare2 -= 32;

            if (compare1 > compare2)
            {
               //cout << compare1 << " " << compare2;   //Testing
               temp = sList[i];
               sList[i] = sList[j];
               sList[j] = temp;

               break;
            }
            else if (compare1 < compare2)
               break;
         }
         //cout << sList[i]->GetLastName() << " " << sList[j]->GetLastName();   //Testing
      }
   }
}

bool StudentList::CreateReportFile(const char* filename)
{
   //Prepares new file for output
   ofstream fout;
   fout.open(filename);
   if (!fout)			// if the open failed
   {
      cerr << "Attempt to create file failed\n";
      return false;
   }

   //Declares letter grade counters
   int aNum = 0, bNum = 0, cNum = 0, dNum = 0, fNum = 0;
   
   //Prints file header
   fout << " Student Grade Summary\n";
   fout << " ---------------------\n";

   //Prints the biology class header
   fout <<" BIOLOGY CLASS\n\n";
   fout << setw(43) << left << " Student" << "Final Final   Letter\n";
   fout << setw(43) << left << " Name" << "Exam  Avg     Grade\n";
   fout <<"----------------------------------------------------------------------\n";
   
   //Prints the biology class content
   for (int i = 0; i < size; i++)
   {
      //Checks if the course is Biology before printing
      if (sList[i]->GetCourse().compare("Biology") == 0)
      {
         fout << sList[i]->GetFirstName() << " " 
         << setw(42 - (sList[i]->GetFirstName().size())) << left
         << sList[i]->GetLastName() << setw(6) << left << sList[i]->GetExam()
         << setw(8) << setprecision(4) << sList[i]->GetFinal();
 
         //Determines which letter grade to print
         if (sList[i]->GetFinal() >= 89.5)
         {
            fout << "A\n";
	    aNum++;
         }
         else if (sList[i]->GetFinal() >= 79.5)
         {   
	    fout << "B\n";
            bNum++;
         }
         else if (sList[i]->GetFinal() >= 69.5)
         {
	    fout << "C\n";
            cNum++;
         }
         else if (sList[i]->GetFinal() >= 59.5)
         {
	    fout << "D\n";
            dNum++;
         }
         else
         {
	    fout << "F\n";
            fNum++;
         }
      }
   }

   //Does the same thing again for the theater and computer science classes
   fout <<" THEATER CLASS\n\n";
   fout << setw(43) << left << " Student" << "Final Final   Letter\n";
   fout << setw(43) << left << " Name" << "Exam  Avg     Grade\n";
   fout <<"----------------------------------------------------------------------\n";

   //Prints the theater class content
   for (int i = 0; i < size; i++)
   {
      //Checks if the course is Theater before printing
      if (sList[i]->GetCourse().compare("Theater") == 0)
      {
         fout << sList[i]->GetFirstName() << " "
         << setw(42 - (sList[i]->GetFirstName().size())) << left
         << sList[i]->GetLastName() << setw(6) << left << sList[i]->GetExam()
         << setw(8) << setprecision(4) << sList[i]->GetFinal();
 
         if (sList[i]->GetFinal() >= 89.5)
         {
            fout << "A\n";
            aNum++;
         }
         else if (sList[i]->GetFinal() >= 79.5)
         {
            fout << "B\n";
            bNum++;
         }
         else if (sList[i]->GetFinal() >= 69.5)
         {
            fout << "C\n";
            cNum++;
         }
         else if (sList[i]->GetFinal() >= 59.5)
         {
            fout << "D\n";
            dNum++;
         }
         else
         {
            fout << "F\n";
            fNum++;
         }

      }
   }

   fout <<" COMPSCI CLASS\n\n";
   fout << setw(43) << left << " Student" << "Final Final   Letter\n";
   fout << setw(43) << left << " Name" << "Exam  Avg     Grade\n";
   fout <<"----------------------------------------------------------------------\n";

   for (int i = 0; i < size; i++)
   {
      if (sList[i]->GetCourse().compare("Computer Science") == 0)
      {
         fout << sList[i]->GetFirstName() << " "
         << setw(42 - (sList[i]->GetFirstName().size())) << left
         << sList[i]->GetLastName() << setw(6) << left << sList[i]->GetExam()
         << setw(8) << setprecision(4) << sList[i]->GetFinal();
 
         //Determines which letter grade to print
         if (sList[i]->GetFinal() >= 89.5)
         {
            fout << "A\n";
            aNum++;
         }
         else if (sList[i]->GetFinal() >= 79.5)
         {
            fout << "B\n";
            bNum++;
         }
         else if (sList[i]->GetFinal() >= 69.5)
         {
            fout << "C\n";
            cNum++;
         }
         else if (sList[i]->GetFinal() >= 59.5)
         {
            fout << "D\n";
            dNum++;
         }
         else
         {
            fout << "F\n";
            fNum++;
         }
      }
   }

   //Prints overall grade distribution
   fout << "\n\n\n OVERALL GRADE DISTRIBUTION\n\n";
   fout << " A:\t" << aNum << endl;
   fout << " B:\t" << bNum << endl;
   fout << " C:\t" << cNum << endl;
   fout << " D:\t" << dNum << endl;
   fout << " F:\t" << fNum << endl;

   return true;
}

//Private functions

void StudentList::Grow()
//Grows the student list as necessary
{
   size ++;			         // Updates the size.
   //cout << "Growth has begun" << endl;   //Testing
   Student** newList = new Student*[size];               // Allocates a new array.
	
   //size > 1 stops this loop from beginning if a slot is being added for the first
   //time. This way, the loop won't copy a nonexistent slot!
   for (int i = 0; i < size && size > 1; i++)	 // Copies data into the new array.
   {
      //cout <<"Beginning copy" << endl;   //Testing
      newList[i] = sList[i];		
   }
   
   delete [] sList;			 // Remove the old array
   //cout << "Delete complete" << endl;    //Testing
   sList = newList;			 // Point old name to new array.
}

void StudentList::Insert(string l, string f, string c, int g[])
// Insert a new Student into the list (only used in ImportFile).
// l is lastName, f is firstName, c is course, and g is grades.
{
   //cout << "Insertion has begun" << endl;    //Testing

   //Decides which type of student to make based on the course input
   if (c.compare("Biology") == 0)
      sList[size - 1] = new Biology(l, f, g);
   else if (c.compare("Theater") == 0)
      sList[size - 1] = new Theater(l, f, g);
   else
      sList[size - 1] = new Comp(l, f, g);                  
}

