//----------------- STUDENTLIST.H -----------------

#include <string>
#include "student.h"

class StudentList
{
public:
   StudentList();		// starts out empty
   ~StudentList();		// cleanup (destructor)

   bool ImportFile(const char* filename);
   bool CreateReportFile(const char* filename);
   void ShowList() const;	// print basic list data
   void SortList() const;       // sort list data

private:
   int size;                    // Size of the list
   Student** sList;		// pointer to the list of students

   void Grow();		        // Increase the length of the list
   void Insert(string l, string f, string c, int g[]);  // Adds a new student to the list
};
