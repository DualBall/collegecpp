//--------------- TEMPERATURE.CPP ---------------
// The class definition for temperatures.
//

#include <iostream>
#include <iomanip>
#include <cctype>
#include "temperature.h"

using namespace std;

//Constructs the Temperature object
Temperature::Temperature(double d, char s)
{
   //Checks for invalid scales
   //If the scale is not Celsius, Fahrenheit, or
   //Kelvin, it will default to Celsius.
   if (s != 'C' && s != 'F' && s != 'K' && s != 'c' && s != 'f' && s != 'k')
      scale = 'C';
   else
      scale = toupper(s);  //Set to uppercase to assist Compare

   //Checks for invalid temperatures
   //If the temperature is below 0 Kelvin, it
   //will default to 0 Celsius
   if ((scale == 'C' || scale == 'c') && (d < -273.15))
      degrees = 0;

   else if ((scale == 'F' || scale == 'f') && (d < -459.67))
   {
      degrees = 0;
      scale = 'C';
   }

   else if ((scale == 'K' || scale == 'k') && (d < 0))
   {
      degrees = 0;
      scale = 'C';
   }

   else
      degrees = d;

   //Sets the format to default
      format = 'D';
}

Temperature::Temperature()
{
   //Sets the temperature and format to the default
   scale = 'C';
   degrees = 0;
   format = 'D';
}

//Gets degrees
double Temperature::GetDegrees() const
{
   return degrees;
}

//Gets scale
char Temperature::GetScale() const
{
   return scale;
}

//Compares one temperature to another, without changing
//either object
//Returns -1 if parameter is higher temperature, 0 if
//temperatures are the same, and 1 if parameter temperature is lower.
//Borrows code from Convert, since Convert cannot
//actually be used here.
int Temperature::Compare(const Temperature&d)
{
   double temp = d.GetDegrees();  //A temporary storage for conversions
   //Starts by checking for identical scales to save time
   if (scale == d.GetScale())
   {
      if (degrees < temp)
         return -1;
      else if (degrees == temp)
         return 0;
      else if (degrees > temp)
         return 1;
   }

   if (scale == 'C')
   {
      if (d.GetScale() == 'F')
      {
         temp = ((d.GetDegrees() * (9/5)) + 32);
         if (temp < degrees)
            return -1;
         else if (degrees == temp)
            return 0;
         else if (temp > degrees)
            return 1;
      }

      else if (d.GetScale() == 'K')
      {
         temp += 273.15;
         if (temp < degrees)
         return -1;
         else if (degrees == temp) 
         return 0;
         else if (temp > degrees)
         return 1;
      }
   }
   if (scale == 'F')
   {
      if (d.GetScale() == 'C')
      {
         temp = (degrees - 32) * (5/9);
         if (temp < degrees)
            return -1;
         else if (degrees == temp)
            return 0;
         else if (temp > degrees)
            return 1;
      }

      else if (d.GetScale() == 'K')
      {
         temp = ((degrees - 32) * (5/9)) + 273.15;
         if (temp < degrees)
            return -1;
         else if (degrees == temp)
            return 0;
         else if (temp > degrees)
            return 1;
      }
   }

   if (scale == 'K')
   {
      if (d.GetScale() == 'C')
      {
         temp -= 273.15;
         if (temp < degrees) 
            return -1;            
         else if (degrees == temp)
            return 0;            
         else if (temp > degrees)   
            return 1;
      }

      else if (d.GetScale() == 'F')
      {
         temp = ((degrees - 273.15 ) * (9/5)) + 32;
         if (temp < degrees) 
            return -1;            
         else if (temp == degrees)
            return 0;            
         else if (temp > degrees)   
            return 1;
      }
   }
}

//Sets a new temperature
//Checks for invalid temperatures first. Returns false
//if input is invalid, and returns true if it is valid.
//Borrows code from the constructor, since this function
//largely serves the same purpose.
bool Temperature::Set(double deg, char s)
{
   //Checks for invalid scales
   //If the scale is not Celsius, Fahrenheit, or
   //Kelvin, it will default to Celsius.
   if (s != 'C' && s != 'F' && s != 'K' && s != 'c' && s != 'f' && s != 'k')
      return false;
   else
      scale = s;

   //Checks for invalid temperatures
   //If the temperature is below 0 Kelvin, it
   //will default to 0 Celsius
   if ((scale == 'C' || scale == 'c') && (deg < -273.15))
      return false;
   else if ((scale == 'F' || scale == 'f') && (deg < -459.67))
      return false;
   else if ((scale == 'K' || scale == 'k') && (deg < 0))
      return false;
   else
      degrees = deg;

   return true;
}

//Sets the format
//Checks for invalid input first, and returns false if
//it is invalid. Otherwise, it will return true.
bool Temperature::SetFormat(char f)
{
   if (f != 'D' && f != 'P' && f != 'L')
      return false;
   else
   {
      format = f;
      return true;
   }
}

//Converts the temperature to a new scale
//Checks for invalid scales using code from constructor.
bool Temperature::Convert (char sc)
{
   //Checks for invalid scales
   if (sc != 'C' && sc != 'F' && sc != 'K' && sc != 'c' && sc != 'f' && sc != 'k')
      return false;

   //Converts temperature accordingly
   if (scale == 'C')
   {
      if (sc == 'F' || sc == 'f')
      {
         degrees = (degrees * (9/5)) + 32;
         scale = sc;
         return true;
      }

      else if (sc == 'K' || sc == 'k')      
      {
         degrees += 273.15;
         scale = sc;
         return true;
      }
   }

   if (scale == 'F')
   {
      if (sc == 'C' || sc == 'c')
      {
         degrees = (degrees - 32) * (5/9);
         scale = sc;
         return true;
      }

      else if (sc == 'K' || sc == 'k')
      {
         degrees = ((degrees - 32) * (5/9)) + 273.15;
         scale = sc;
         return true;
      }
   }

   if (scale == 'K')
   {
      if (sc == 'C' || sc == 'c')
      {
         degrees -= 273.15;
         scale = sc;
         return true;
      }

      else if (sc == 'F' || sc == 'f')
      {
         degrees = ((degrees - 273.15 ) * (9/5)) + 32;
         scale = sc;
         return true;
      }
   }
}

//Increments the temperature
void Temperature::Increment(int deg, char sc)
{
   if (scale == toupper(sc))
      degrees += deg;
}

//Allows the user to input a new temperature
//Borrows code from constructor for error checking
void Temperature::Input()
{
   //Temporary storage for error checking
   double d;
   char s;

   cout << "Please enter a temperature: ";
   cin >> d >> s;

   //Uses Set to check if an error message should print
   while (!Set(d, s))
   {
      cout << "Invalid temperature. Try again: ";
      cin >> d >> s;
   }
}

//Shows the current temperature to the user, in the appropriate format
void Temperature::Show()
{
   if (format == 'D')
      cout << degrees << " " << scale;

   else if (format == 'P')
   {
      // capture current output stream settings
      int oldprecision = cout.precision();
      char oldfill = cout.fill();
      ios_base::fmtflags oldflags = cout.flags();

      cout << setprecision(1) << degrees << " " << scale;  

      //PUT THINGS BACK THE WAY THEY WERE WHEN I FOUND THEM
      cout.precision(oldprecision);	// restore old precision setting
      cout.fill(oldfill);			// restore old fill char setting
      cout.flags(oldflags);		// restore all prior format flags
   }
   
   else if (format == 'L')
   {
      cout << degrees;

      if (scale == 'C')
         cout << " Celsius";
      else if (scale == 'F')
         cout << " Fahrenheit";
      else if (scale == 'K')
         cout << " Kelvin";
   }
}
