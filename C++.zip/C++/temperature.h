//--------------- TEMPERATURE.H ---------------

class Temperature
{
public:
   //Constructor with parameters for degrees and scale, respectively
   Temperature(double d, char s);

   //Default constructor
   Temperature();

   //getters
   double GetDegrees() const;
   char GetScale() const;
   int Compare(const Temperature&d);

   //setters
   bool Set(double deg, char s);
   bool SetFormat(char f);

   // mutators
   bool Convert(char sc);
   void Increment(int deg, char sc);
   
   //display functions
   void Input();
   void Show();

private:
   double degrees;   //the temperature                  
   char scale;  //The scale of the temperature
   char format;  //The format in which to show the temprature
};

